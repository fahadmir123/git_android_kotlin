# RetrofitDemo-Tutorial-Series

Playlist: https://www.youtube.com/playlist?list=PLSrm9z4zp4mF1Ssdfuocy2XH5Bw4wLLNw
![alt text](https://i.postimg.cc/vmNzY16D/retrofit-post.png)
