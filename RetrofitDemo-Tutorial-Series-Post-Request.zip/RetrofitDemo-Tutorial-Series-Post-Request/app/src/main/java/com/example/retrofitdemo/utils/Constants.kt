package com.example.retrofittest.utils

class Constants {

    companion object{
        const val BASE_URL = "http://jsonplaceholder.typicode.com"
    }

}